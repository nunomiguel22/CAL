#include "Reader.h"
#include "Graph.h"
#include "OSMServices.h"
#include "rideshare.h"
#include "timeofday.h"

void mainMenu();
void usersMenu();
void routeMenu();
void goBack();
void createNewRoute();
void createNewUser();
//void showAllUsers();
//void removeUser();
void findRide();
void printtitle();
void driverSetUp(User driver);
void ClearScreen();
bool SetWindow(const int& width, const int& height);

void exit();